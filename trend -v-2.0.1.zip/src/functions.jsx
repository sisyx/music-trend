import { apiroot, root } from "./constatnts";


// Campaigns

export async function getAllCamps() {
    try {
        let hasCampInsta = true;
        let hasCampTel = true;
        const reqInsta = await fetch(`${root}/api/CampInstagram/GetAll`);
        const reqTel = await fetch(`${root}/api/CampTel/GetAll`);

        if (!reqInsta.ok) {
            if (reqInsta.status !== 404) {
                throw new Error("Failed to get All camps");
            } else {
                hasCampInsta = false;
            }
        }
        
        if (!reqTel.ok) {
            if (reqTel.status !== 404) {
                throw new Error("Failed to get All camps")
            }
            else {
                hasCampTel = false;
            }
        }

        const resInsta = hasCampInsta ? await reqInsta.json() : [];
        const resTel = hasCampTel ? await reqTel.json() : [];
        console.log(resInsta);
        const formatedResInsta = resInsta.map(camp =>  {
            return {
                name: camp.CampaignName,
                type: "instagram",
                id: camp.Id
            }});
        const formatedResTel = resTel.map(camp => {
            return {
                name: camp.CampaignName,
                type: "telegram",
                id: camp.Id
            }});
        return [...formatedResInsta, ...formatedResTel];
    } catch (error) {
        console.error(error.message)
    }
}

export async function createCampaign(name, type) {
    const reqBody = {
        campaignName: name,
        ownerid: 1,
    }
    try {
        const req = await fetch(`${root}/api/${type === "telegram" ? "CampTel/CreateCampaigne" : "CampInstagram/createcampaign"}`, {
            method: "POST",
            body: JSON.stringify(reqBody),
            headers: {
                "Content-Type": "application/json",
            }
        });

        if (!req.ok) {
            throw new Error("Failed to add campaign")
        }

        const res = await req.json();
        console.log(res);
        return res.Message

    } catch (error) {
        console.error(error.message);
        return error.message
    }
}

export async function getCampWithId(id, type) {
    let url;
    if (type === "instagram") 
        url = `${root}/api/CampInstagram/GetAll`
    else
        url = `${root}/api/CampTel/GetAll`
    try {
        let hasCamp = true;
        const req = await fetch(url);

        if (!req.ok) {
            if (req.status !== 404) {
                throw new Error("Failed to get All camps");
            } else {
                hasCampInsta = false;
            }
        }

        const res = hasCamp ? await req.json() : [];
        const formatedReredsInsta = type === "instagram" ?  res.map(camp =>  {
            return {
                name: camp.CampaignName,
                type: "instagram",
                id: camp.Id
            }}) : {};
        const formatedResTel = type === "telegram" ? res.map(camp => {
            return {
                name: camp.CampaignName,
                type: "telegram",
                id: camp.Id
            }}) : {};

        let foundCampaign;
        if (type === "instagram") 
            foundCampaign = formatedReredsInsta.find(camp => camp.id == id)
        else 
            foundCampaign = formatedResTel.find(camp => camp.id == id)
        console.log(foundCampaign)
        return foundCampaign
    } catch (error) {
        console.error(error.message)
    }
}

// Publishers
export async function createPublisher(platformid, type, campaignId) {
    const reqBody = type === 'instagram' 
    ? {
        pageId: platformid,
        postViews: 0,
        postLink: "x",
        postLikes: 0,
        postComments: 0,
        postImpertion: 0,
        storyViews: 0,
        storyImpertion: 0,
        campaignId: campaignId
    } 
    : {
        postViews: 0,
        postLink: "x",
        channelId: platformid,
        campaignId: campaignId
    }
    try {
        const req = await fetch(`${root}/api/${type === "telegram" ? "PublisherTel/CreatePublisher" : "PublisherInstagram/CreatePublisher"}`, {
            method: "POST",
            body: JSON.stringify(reqBody),
            headers: {
                "Content-Type": "application/json",
            }
        });

        if (!req.ok) {
            throw new Error("Failed to add campaign")
        }

        const res = await req.json();
        console.log(res);
        return res.Message

    } catch (error) {
        console.error(error.message);
        return error.message
    }
}

export async function getPublishers(campaignId, type) {
    let url = type === "instagram" ? `${root}/api/PublisherInstagram/GetPublisherByCampaignId?campaignId=${campaignId}` : `${root}/api/PublisherTel/GetPublisherByCampaignId?campaignId=${campaignId}`

    try {
        const req = await fetch(url);

        if (!req.ok) {
            throw new Error("Failed to get publishers");
        }

        const res = await req.json();
        const formatedResInsta = type === "instagram" ? res.map(obj => {
            return {
                platformid: obj.PageId,
                campaignId: obj.CampaignId,
                type: "instagram",
                ...obj
            }
        }) : {}
        const formatedResTel = type === "telegram" ? res.map(obj => {
            return {
                platformid: obj.ChannelId,
                campaignId: obj.CampaignId,
                type: "telegram",
                ...obj
            }
        }) : {}
        if (type === "instagram") return formatedResInsta
        else return formatedResTel
    } catch (error) {
        console.error(error.message);
        return [];
    }

}

export async function updatePublisher(publisherId, newData, type) {
    let url;
    if (type === "instagram") {
        url = `${root}/api/PublisherInstagram/EditPublisher?publisherId=${publisherId}`
    } else {
        url = `${root}/api/PublisherTel/EditPublisher?publisherId=${publisherId}`
    }

    try {
        const req = await fetch(url, {
            method: "POST",
            body: JSON.stringify(newData),
            headers: {
                "Content-Type": "application/json"
            }
        })

        if (!req.ok) {
            throw new Error("Failed to edit Publisher")
        }

        const res = await req.text();
        return res
    } catch (error) {
        console.log(error.message);
        return "مشکلی در ادیت کردن پابلیشر ایجاد شده. لطفا دوباره امتحان کنید"
    }
}


// instagram and telegram apis

export async function getInstaUser(username) {
    try {
        const req = await fetch(`${apiroot}/api/instagram/GetBusinessDiscoveryData?username=${username}`);
        
        if (!req.ok) {
            throw new Error("failed to fetch data from instagram");
        }

        const res = await req.json();
        console.log(res);
        return res;
    } catch (error) {
        console.log(error.message);
        return {}
    }
}

export async function getTelegramChannel(channelId) {
    try {
        const req = await fetch(`${apiroot}/api/Telegram/GetChannelProfilePhoto/@${channelId}`);
        
        if (!req.ok) {
            throw new Error("failed to fetch data from telegram");
        }

        const res = await req.json();
        console.log(res);
        return res;
    } catch (error) {
        console.log(error.message);
        return {}
    }
}


// ui scripts
export async function customAlert(text) {
    // remove previous alerts
    document.querySelectorAll(".sisyx-own-custom-alert").forEach(xalert => xalert.remove());
    const alertHeader = document.createElement("div");
    alertHeader.classList = "text-red-400 w-full text-right"
    alertHeader.innerHTML = "پیام سیستم"
    const div = document.createElement("div");
    // tailwind classes
    div.classList = "sisyx-own-custom-alert fixed bg-black text-white bottom-3 right-3 p-2 flex flex-col gap-2";
    
    // append elements to document
    div.appendChild(alertHeader)
    div.innerHTML += text;
    document.body.appendChild(div);

    const alertElement = document.querySelector(".sisyx-own-custom-alert");
    setTimeout(() => {
        alertElement.remove();
    }, 5000);
}


// other functions
export function copy(text) {
    navigator.clipboard.writeText(text);
    const reportText = `<div dir="rtl" class="flex gap-2 items-center">
        <code class="font-bold text-red" dir="ltr">
            ${text.slice(0, 30)}${text.length > 30 ? "..." : ""} 
        </code>
        در کلیپ برد کپی شد</div>`;
    customAlert(reportText)
}