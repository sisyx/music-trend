import Footer from "../../components/Footer";
import Aboutus from "../../components/home/Aboutus";
// import Chart from "../../components/home/Chart";
import HomeChart from "../../components/home/HomeChart";
import HomeTimeline from "../../components/home/HomeTimeline";
import NoBg from "../../components/home/NoBg";
import TsParticles from "../../components/home/TsParticles";
import XCards from "../../components/home/XCards";
import Navbar from "../../components/Navbar";
import Separator from "../../components/Separator";
import Wave from "../../components/Wave";
import {  configs4 } from "../../constatnts";

function Home() {
    return ( 
        <div>
        <Navbar />
        <Wave topcolor="#2da5dc" bottomcolor="#fff" className="mt-12" />
        <XCards />
        <Wave topcolor="white" bottomcolor="#f3f4f6" rotate={true} height="150px" />
        <Aboutus />
        <Wave topcolor="#f3f4f6" bottomcolor="#fff" rotate={true} styles={{boxShadow: "0 0 5px black"}}/>
        {/* <Chart /> */}
        <HomeTimeline />
        <Separator topcolor="#fff" bottomcolor="#0000" reverse="true" />
        <NoBg />
        <Separator topcolor="#0000" bottomcolor="#5e298e" />
        <HomeChart />
        <Wave topcolor="#5e298e" bottomcolor="#111827" styles={{boxShadow: "0 0 5px black"}}/>
        <Footer />
        <TsParticles options={configs4} />
        </div>
     );
}

export default Home;