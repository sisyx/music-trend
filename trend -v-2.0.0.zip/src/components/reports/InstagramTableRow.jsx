import { Instagram } from "@mui/icons-material";
import { getInstaUser } from "../../functions";
import { useEffect, useState } from "react";
import { CgProfile } from "react-icons/cg";

function InstagramTableRow({ publisher, index }) {
    const [xpublisher, setXPulisher] = useState({});
    const [imageStatus, setImageStatus] = useState({
        isLoading: true,
        isLoaded: false,
    })

    useEffect(() => {
        init();
    }, [])

    async function init() {
        const tmpUser = await getInstaUser(publisher.PageId);
        setXPulisher(tmpUser);
    }

    return ( 
        <tr className='bg-white hover:bg-gray-300 transition-all duration-100 cursor-pointer'>
            <td className='py-2'>
                {
                    xpublisher?.ProfilePictureUrl
                    ? <img 
                        src={
                            xpublisher.ProfilePictureUrl
                        } 
                        onLoad={() => setImageStatus(cur => {
                           return {...cur, isLoading: false, isLoaded: true}
                        })}
                        onError={() => setImageStatus(cur => {
                            return {...cur, isLoading: false, isLoaded: false}
                         })}
                        alt=""
                    />  
                    : ""
                }
                {
                    !imageStatus.isLoaded 
                    ? <CgProfile fontSize="2rem" />
                    : ""
                }
            </td>
            <td className='py-2'>{publisher.PageId}</td>
            <td className='py-2'>{xpublisher?.Name ? xpublisher.Name : "Loading"}</td>
            <td className='py-2'>{xpublisher?.FollowersCount ? xpublisher?.FollowersCount : "Loading"}</td>
            <td className='py-2'>{publisher.PostImpertion}</td>
            <td className='py-2'>{publisher.PostLikes}</td>
            <td className='py-2'>{publisher.PostViews}</td>
            <td className='py-2'>{publisher.postComments}</td>
            <td className='py-2'>{publisher.StoryImpertion}</td>
            <td className='py-2'>{publisher.StoryViews}</td>
            <td>
                <a href={`https://${publisher.PostLink}`} className="text-2xl bg-gradient-to-r from-transparent to-transparent  hover:from-primary-start hover:to-primary-end hover:text-white duration-0 transition-all">
                    <Instagram sx={{fontSize: "2rem"}} />
                </a>
            </td>
        </tr>
     );
}

export default InstagramTableRow;