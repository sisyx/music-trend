import './fonts.css';
import './App.css';
import './general.css';

import React, { Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { ThemeProvider } from './contexts/themeContext';
import Loading from './components/loadings/Loading';
const Admin = React.lazy(() => import('./pages/admin/Admin'));
import InstagramReport from './pages/report/InstagramReport';
import TelegramReport from './pages/report/TelegramReport';
const Start = React.lazy(() => import("./pages/start/Start"));
const AboutUsPage = React.lazy(() => import("./pages/other/AboutUsPage"));
const Login = React.lazy(() => import('./pages/login/Login'));
const Home = React.lazy(() => import('./pages/home/Home'));

function App() {

  return (
    <ThemeProvider>
        <Suspense fallback={<Loading />}>
          <Routes>
            <Route index exact element={<Home />} />
            <Route path='/admin' exact element={<Admin />} />
            <Route path='/login' element={<Login />} />
            <Route path='/aboutus' element={<AboutUsPage />} />
            <Route path='/start' element={<Start />} />
            <Route path='/reports/instagram' element={<InstagramReport />} />
            <Route path='/reports/telegram' element={<TelegramReport />} />
          </Routes>
      </Suspense>
    </ThemeProvider>
  )
}

export default App