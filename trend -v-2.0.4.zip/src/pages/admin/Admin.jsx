import { useEffect, useReducer, useState } from "react";
import NoCamp from "../../components/admin/NoCamp";
import Main from "../../components/admin/Main";
import { customAlert, getAllCamps } from "../../functions";
function Admin() {
    
    const [isLoaded, setIsLoaded] = useState(false);
    const [campaigns, dispatch] = useReducer(reducer, []);

    useEffect(() => {
        // getAllCamps();
        init();
    }, []);

    useEffect(() => {
        console.log(campaigns)
    }, campaigns);

    async function init() {
        const tmpCamps = await getAllCamps();
        console.log(tmpCamps);
        // customAlert("کمپین ها بارگیری شدند")
        dispatch({type: "set camps", payload: {camps: tmpCamps}});
        setIsLoaded(true)
    }

    return (
        <div className="bg-gray-700 text-white">
            {
                isLoaded 
                ? <>
                    {
                        !campaigns?.length 
                        ? <NoCamp dispatch={dispatch} /> 
                        : 
                        <Main campaings={campaigns} dispatch={dispatch} />
                    }
                </>
                : <h1>Loading</h1>
            }
        </div>
     );
}

export default Admin;


function reducer(state, action) {
    if (!action) return

    switch (action.type) {
        case "add": return [{name: action.payload.name, type: action.payload.type, id: action.payload.id}]

        case "select": return state.map(x => x.id === action.payload.id && x.type === action.payload.type ? {...x, selected: true} : {...x, selected: false});

        case "set camps": return [...action.payload.camps];
    }

}