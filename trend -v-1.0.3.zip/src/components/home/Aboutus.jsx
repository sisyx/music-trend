import { PiArrowRight } from "react-icons/pi";
import { Link } from "react-router-dom";

function Aboutus() {
    return ( 
        <div className="bg-gray-100 h-screen flex justify-center vazirmatn">
            {/* inner container */}
            <div className="flex items-center max-w-6xl">
                {/* Left */}
                <div className="w-1/2 flex flex-col items-start gap-12 group">
                    {/* title */}
                    <div className="font-black text-right w-full text-primary-end text-4xl group-hover:text-primary-start transition-all duration-200">ما کی هستیم؟</div>
                    {/* text */}
                    <div dir="rtl" className="relative first-letter:text-primary-start first-letter:text-3xl text-justify pl-2 before:content-[''] before:absolute before:block before:h-0 group-hover:before:h-full before:w-1 before:bg-gradient-to-b before:from-primary-start before:to-primary-end before:-right-2 before:transition-all before:duration-500 cursor-pointer">
                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، 
                    </div>
                    {/* button */}
                    <Link to="/aboutus">
                        <button type="button" class="flex items-center justify-evenly gap-2 text-black hover:text-primary-start hover:gap-4 transition-all duration-150 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                            بیشتر بدانید
                            <PiArrowRight />
                        </button>
                    </Link>
                </div>
                {/* Right */}
                <div className="w-1/2 flex items-center justify-center">
                    <img src="/src/assets/images/aboutus2.png" alt="" />
                </div>
            </div>
        </div>
     );
}

export default Aboutus;